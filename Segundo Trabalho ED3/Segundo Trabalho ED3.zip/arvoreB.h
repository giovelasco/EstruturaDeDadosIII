/*
Nome: Gabriel Balbão Bazon - NUSP: 13676408
Nome: Giovanna de Freitas Velasco - NUSP: 13676346
*/

#include <stdio.h>
#include <stdlib.h>
#include "registros.h"
#include "registros_indice.h"

int BuscaArvoreB(FILE *indiceBIN, char *chaveDeBusca);

void InsercaoArvoreB(FILE *indiceBIN, cabecalhoIndice *cabInd, char *chaveDeBusca, int RRNdados, int *alturaArvore);