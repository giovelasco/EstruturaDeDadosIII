/*
Nome: Gabriel Balbão Bazon - NUSP: 13676408
Nome: Giovanna de Freitas Velasco - NUSP: 13676346
*/

#include "funcoes_grafos.h"

void Funcionalidade8(char *nomeDadosBIN);

void Funcionalidade9(char *nomeDadosBIN);

void Funcionalidade10(char *nomeDadosBIN, int n);

void Funcionalidade11(char *nomeDadosBIN);

void Funcionalidade12(char *nomeDadosBIN, int n);
